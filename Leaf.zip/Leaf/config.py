"""
Configuration settings for the Discord ID Converter Bot
"""

# Bot settings
BOT_PREFIX = '!'
BOT_DESCRIPTION = 'A Discord bot that converts user IDs to usernames'

# Command settings
MAX_IDS_PER_COMMAND = 150  # Maximum number of IDs to process in one command (range: 100-200)
RESULTS_PER_MESSAGE = 10  # Number of results to show per message
SHOW_PROFILE_PICTURES = True  # Whether to show profile pictures with conversion results
PROFILE_PICTURE_SIZE = 512  # Size of profile pictures (128, 256, 512, 1024)

# Error messages
ERROR_MESSAGES = {
    'invalid_id': '❌ {id}: Invalid user ID format',
    'user_not_found': '❌ {id}: User not found',
    'fetch_error': '❌ {id}: Error fetching user data',
    'too_many_ids': '❌ Too many IDs provided. Maximum allowed: {max_ids}',
    'no_ids_provided': '❌ Please provide at least one user ID',
    'general_error': '❌ {id}: Error - {error}'
}

# Success message format
SUCCESS_MESSAGE = '✅ {id}: @{username} (Display: {display_name})'
SUCCESS_MESSAGE_WITH_NICK = '✅ {id}: @{username} (Display: {display_name}, Nickname: {nickname})'

# Embed colors
EMBED_COLORS = {
    'success': 0x00ff00,
    'error': 0xff0000,
    'info': 0x0099ff
}