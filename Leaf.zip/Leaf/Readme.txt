STEPS

1 request your data from discord 

2 create a discord bot

3 go to [](https://discord.com/developers/applications)

4 add bot to your server

5 in bot tab, **Privileged Gateway Intents > Presence Intent IS ON > Server Members Intent IS ON > Message Content Intent IS ON** 

6 in 0auth2 go to OAuth2 URL Generator, make sure these are on:

<img width="1920" height="1080" alt="Image" src="https://github.com/user-attachments/assets/be9a2350-09c1-4566-a9f4-9f5295bedbe2" />

7 copy bot token

8 put in the ".ENV" file

9 make sure to open a cmd and install: "pip install python-dotenv" , and "pip install discord.py"

10 open a terminal / cmd

11 cd to your desktop or this C:\Users\(your user)\Desktop\Leaf 

12 run the command: python bot.py

13 make sure it is online in your server

use manus to extract the discord ids and use the !convert (ids) in bulk or single one to get its user, id, current profile picture.


