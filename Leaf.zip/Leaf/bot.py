import discord
from discord.ext import commands
import os
import asyncio
from typing import List, Optional
import logging
from config import *
from dotenv import load_dotenv

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class IDConverterBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        
        super().__init__(
            command_prefix=BOT_PREFIX,
            description=BOT_DESCRIPTION,
            intents=intents
        )
    
    async def on_ready(self):
        logger.info(f'{self.user} has connected to Discord!')
        logger.info(f'Bot is in {len(self.guilds)} guilds')
        
        # Set bot status
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name=f"for {BOT_PREFIX}help | ID Converter"
        )
        await self.change_presence(activity=activity)

class IDConverter(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    async def fetch_user_safe(self, user_id: int) -> Optional[discord.User]:
        """Safely fetch a user by ID with proper error handling"""
        try:
            # Try cache first
            user = self.bot.get_user(user_id)
            if user:
                return user
            
            # Fetch from API if not in cache
            user = await self.bot.fetch_user(user_id)
            return user
        except discord.NotFound:
            return None
        except discord.HTTPException as e:
            logger.warning(f"HTTP error fetching user {user_id}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error fetching user {user_id}: {e}")
            return None
    
    def format_user_result(self, user_id: int, user: discord.User, guild_member: Optional[discord.Member] = None) -> str:
        """Format the result string for a user"""
        username = user.name
        display_name = user.display_name if hasattr(user, 'display_name') else username
        
        if guild_member and guild_member.nick:
            return SUCCESS_MESSAGE_WITH_NICK.format(
                id=user_id,
                username=username,
                display_name=display_name,
                nickname=guild_member.nick
            )
        else:
            return SUCCESS_MESSAGE.format(
                id=user_id,
                username=username,
                display_name=display_name
            )
    
    async def send_results_chunked(self, ctx, results: List[dict], title: str = "ID to Username Conversion Results"):
        """Send results in chunks to avoid Discord message limits"""
        if not results:
            await ctx.send("No results to display.")
            return
        
        for i in range(0, len(results), RESULTS_PER_MESSAGE):
            chunk = results[i:i + RESULTS_PER_MESSAGE]
            
            # Create main embed with results
            embed = discord.Embed(
                title=title,
                color=EMBED_COLORS['info']
            )
            
            # Add text results
            text_results = []
            for result in chunk:
                if result['success']:
                    text_results.append(result['text'])
                else:
                    text_results.append(result['text'])
            
            embed.description = "\n".join(text_results)
            
            if len(results) > RESULTS_PER_MESSAGE:
                embed.set_footer(text=f"Results {i+1}-{min(i+RESULTS_PER_MESSAGE, len(results))} of {len(results)}")
            
            await ctx.send(embed=embed)
            
            # Send profile pictures for successful results (if enabled)
            if SHOW_PROFILE_PICTURES:
                profile_embeds = []
                for result in chunk:
                    if result['success'] and result.get('avatar_url'):
                        profile_embed = discord.Embed(
                            title=f"Profile Picture - {result['username']}",
                            color=EMBED_COLORS['success']
                        )
                        profile_embed.set_image(url=result['avatar_url'])
                        profile_embed.add_field(name="User ID", value=str(result['user_id']), inline=True)
                        profile_embed.add_field(name="Username", value=f"@{result['username']}", inline=True)
                        profile_embeds.append(profile_embed)
                
                # Send profile picture embeds
                for profile_embed in profile_embeds:
                    await ctx.send(embed=profile_embed)
                    await asyncio.sleep(0.3)  # Small delay between profile pictures
            
            # Small delay between message chunks
            if i + RESULTS_PER_MESSAGE < len(results):
                await asyncio.sleep(0.5)
    
    @commands.command(name='convert', aliases=['conv', 'ids'], help='Convert user IDs to usernames')
    async def convert_ids(self, ctx, *user_ids):
        """
        Convert user IDs to usernames with profile pictures
        Usage: !convert 123456789 987654321 555666777
        """
        if not user_ids:
            await ctx.send(ERROR_MESSAGES['no_ids_provided'])
            return
        
        if len(user_ids) > MAX_IDS_PER_COMMAND:
            await ctx.send(ERROR_MESSAGES['too_many_ids'].format(max_ids=MAX_IDS_PER_COMMAND))
            return
        
        # Send typing indicator for longer operations
        async with ctx.typing():
            results = []
            
            for user_id_str in user_ids:
                try:
                    user_id = int(user_id_str)
                    
                    user = await self.fetch_user_safe(user_id)
                    
                    if user is None:
                        results.append({
                            'success': False,
                            'user_id': user_id,
                            'text': ERROR_MESSAGES['user_not_found'].format(id=user_id),
                            'username': None,
                            'avatar_url': None
                        })
                        continue
                    
                    # Check for guild member info
                    guild_member = ctx.guild.get_member(user_id) if ctx.guild else None
                    result_text = self.format_user_result(user_id, user, guild_member)
                    
                    # Get avatar URL (configurable resolution)
                    avatar_url = None
                    if user.avatar:
                        avatar_url = user.avatar.with_size(PROFILE_PICTURE_SIZE).url
                    elif user.default_avatar:
                        avatar_url = user.default_avatar.url
                    
                    results.append({
                        'success': True,
                        'user_id': user_id,
                        'text': result_text,
                        'username': user.name,
                        'display_name': user.display_name if hasattr(user, 'display_name') else user.name,
                        'avatar_url': avatar_url
                    })
                    
                except ValueError:
                    results.append({
                        'success': False,
                        'user_id': user_id_str,
                        'text': ERROR_MESSAGES['invalid_id'].format(id=user_id_str),
                        'username': None,
                        'avatar_url': None
                    })
                except Exception as e:
                    results.append({
                        'success': False,
                        'user_id': user_id_str,
                        'text': ERROR_MESSAGES['general_error'].format(id=user_id_str, error=str(e)),
                        'username': None,
                        'avatar_url': None
                    })
        
        await self.send_results_chunked(ctx, results)
    
    @commands.command(name='convert_list', aliases=['convlist', 'clist'], help='Convert comma-separated list of IDs')
    async def convert_list(self, ctx, *, id_list: str):
        """
        Convert a comma-separated list of user IDs
        Usage: !convert_list 123456789, 987654321, 555666777
        """
        # Parse and clean the list
        user_ids = [id_str.strip() for id_str in id_list.split(',') if id_str.strip()]
        
        if not user_ids:
            await ctx.send(ERROR_MESSAGES['no_ids_provided'])
            return
        
        # Call the main conversion function
        await self.convert_ids(ctx, *user_ids)
    
    @commands.command(name='user_info', aliases=['userinfo', 'info'], help='Get detailed user information')
    async def user_info(self, ctx, user_id: str):
        """
        Get detailed information about a user
        Usage: !user_info 123456789
        """
        try:
            user_id_int = int(user_id)
            
            async with ctx.typing():
                user = await self.fetch_user_safe(user_id_int)
                
                if user is None:
                    await ctx.send(ERROR_MESSAGES['user_not_found'].format(id=user_id))
                    return
                
                # Create detailed embed
                embed = discord.Embed(
                    title="User Information",
                    color=EMBED_COLORS['success']
                )
                
                embed.add_field(name="Username", value=f"@{user.name}", inline=True)
                embed.add_field(name="Display Name", value=user.display_name if hasattr(user, 'display_name') else user.name, inline=True)
                embed.add_field(name="User ID", value=str(user.id), inline=True)
                embed.add_field(name="Account Created", value=user.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
                
                if user.avatar:
                    embed.set_thumbnail(url=user.avatar.url)
                
                # Guild-specific information
                if ctx.guild:
                    guild_member = ctx.guild.get_member(user_id_int)
                    if guild_member:
                        embed.add_field(name="Server Nickname", value=guild_member.nick or "None", inline=True)
                        embed.add_field(name="Joined Server", value=guild_member.joined_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=True)
                        
                        roles = [role.name for role in guild_member.roles[1:]]  # Exclude @everyone
                        embed.add_field(name="Roles", value=", ".join(roles) or "None", inline=False)
                        
                        if guild_member.premium_since:
                            embed.add_field(name="Boosting Since", value=guild_member.premium_since.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=True)
                
                await ctx.send(embed=embed)
                
        except ValueError:
            await ctx.send(ERROR_MESSAGES['invalid_id'].format(id=user_id))
        except Exception as e:
            await ctx.send(ERROR_MESSAGES['general_error'].format(id=user_id, error=str(e)))
    
    @commands.command(name='batch_convert', aliases=['batch'], help='Convert IDs from a text file or message')
    async def batch_convert(self, ctx):
        """
        Convert IDs from an attached text file or reply to a message with IDs
        Usage: !batch_convert (with file attachment or reply to message)
        """
        user_ids = []
        
        # Check for file attachment
        if ctx.message.attachments:
            attachment = ctx.message.attachments[0]
            if attachment.filename.endswith('.txt'):
                try:
                    content = await attachment.read()
                    text = content.decode('utf-8')
                    # Extract numbers from text
                    import re
                    user_ids = re.findall(r'\b\d{15,20}\b', text)  # Discord IDs are 15-20 digits
                except Exception as e:
                    await ctx.send(f"Error reading file: {str(e)}")
                    return
        
        # Check for replied message
        elif ctx.message.reference:
            try:
                replied_msg = await ctx.fetch_message(ctx.message.reference.message_id)
                import re
                user_ids = re.findall(r'\b\d{15,20}\b', replied_msg.content)
            except Exception as e:
                await ctx.send(f"Error reading replied message: {str(e)}")
                return
        
        if not user_ids:
            await ctx.send("Please attach a .txt file with user IDs or reply to a message containing user IDs.")
            return
        
        # Limit the number of IDs
        if len(user_ids) > MAX_IDS_PER_COMMAND:
            user_ids = user_ids[:MAX_IDS_PER_COMMAND]
            await ctx.send(f"⚠️ Limited to first {MAX_IDS_PER_COMMAND} IDs found.")
        
        await self.convert_ids(ctx, *user_ids)

# Bot setup and error handling
bot = IDConverterBot()

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("❌ Command not found. Use `!help` to see available commands.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing required argument. Use `!help {ctx.command}` for usage information.")
    elif isinstance(error, commands.BadArgument):
        await ctx.send(f"❌ Invalid argument provided. Use `!help {ctx.command}` for usage information.")
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(f"❌ Command is on cooldown. Try again in {error.retry_after:.2f} seconds.")
    else:
        logger.error(f"Unhandled error in command {ctx.command}: {error}")
        await ctx.send(f"❌ An unexpected error occurred: {str(error)}")

# Add the cog
async def setup():
    await bot.add_cog(IDConverter(bot))

# Run the bot
if __name__ == "__main__":
    load_dotenv() # Load environment variables from .env file
    token = os.getenv("DISCORD_BOT_TOKEN")
    if token:
        print("DISCORD_BOT_TOKEN loaded successfully.")
    else:
        print("Error: DISCORD_BOT_TOKEN environment variable not set!")
        print("Please set your Discord bot token as an environment variable.")
        exit(1)
    
    # Setup and run
    asyncio.run(setup())
    bot.run(token)


    @commands.command(name='avatars', aliases=['pfp', 'pictures'], help='Show only profile pictures for user IDs')
    async def show_avatars(self, ctx, *user_ids):
        """
        Show only profile pictures for user IDs
        Usage: !avatars 123456789 987654321 555666777
        """
        if not user_ids:
            await ctx.send(ERROR_MESSAGES['no_ids_provided'])
            return
        
        if len(user_ids) > MAX_IDS_PER_COMMAND:
            await ctx.send(ERROR_MESSAGES['too_many_ids'].format(max_ids=MAX_IDS_PER_COMMAND))
            return
        
        async with ctx.typing():
            successful_users = []
            failed_users = []
            
            for user_id_str in user_ids:
                try:
                    user_id = int(user_id_str)
                    user = await self.fetch_user_safe(user_id)
                    
                    if user is None:
                        failed_users.append(f"❌ {user_id}: User not found")
                        continue
                    
                    # Get avatar URL
                    avatar_url = None
                    if user.avatar:
                        avatar_url = user.avatar.with_size(PROFILE_PICTURE_SIZE).url
                    elif user.default_avatar:
                        avatar_url = user.default_avatar.url
                    
                    if avatar_url:
                        successful_users.append({
                            'user_id': user_id,
                            'username': user.name,
                            'display_name': user.display_name if hasattr(user, 'display_name') else user.name,
                            'avatar_url': avatar_url
                        })
                    else:
                        failed_users.append(f"❌ {user_id}: No avatar available")
                        
                except ValueError:
                    failed_users.append(f"❌ {user_id_str}: Invalid user ID format")
                except Exception as e:
                    failed_users.append(f"❌ {user_id_str}: Error - {str(e)}")
            
            # Send failed results first if any
            if failed_users:
                error_embed = discord.Embed(
                    title="❌ Failed to Get Avatars",
                    description="\n".join(failed_users),
                    color=EMBED_COLORS['error']
                )
                await ctx.send(embed=error_embed)
            
            # Send profile pictures in order
            if successful_users:
                await ctx.send(f"📸 **Profile Pictures** ({len(successful_users)} found):")
                
                for user_data in successful_users:
                    profile_embed = discord.Embed(
                        title=f"@{user_data['username']}",
                        color=EMBED_COLORS['success']
                    )
                    profile_embed.set_image(url=user_data['avatar_url'])
                    profile_embed.add_field(name="User ID", value=str(user_data['user_id']), inline=True)
                    profile_embed.add_field(name="Display Name", value=user_data['display_name'], inline=True)
                    
                    await ctx.send(embed=profile_embed)
                    await asyncio.sleep(0.4)  # Delay between pictures
            
            if not successful_users and not failed_users:
                await ctx.send("No valid user IDs provided.")

    @commands.command(name='toggle_pictures', aliases=['toggle_pfp'], help='Toggle profile picture display on/off')
    @commands.has_permissions(manage_messages=True)
    async def toggle_pictures(self, ctx):
        """
        Toggle profile picture display in conversion results
        Usage: !toggle_pictures
        """
        global SHOW_PROFILE_PICTURES
        SHOW_PROFILE_PICTURES = not SHOW_PROFILE_PICTURES
        
        status = "enabled" if SHOW_PROFILE_PICTURES else "disabled"
        embed = discord.Embed(
            title="Profile Picture Display",
            description=f"Profile pictures are now **{status}** in conversion results.",
            color=EMBED_COLORS['success'] if SHOW_PROFILE_PICTURES else EMBED_COLORS['info']
        )
        
        if SHOW_PROFILE_PICTURES:
            embed.add_field(
                name="Note", 
                value="Profile pictures will be shown with `!convert` commands.", 
                inline=False
            )
        else:
            embed.add_field(
                name="Note", 
                value="Use `!avatars` command to see profile pictures only.", 
                inline=False
            )
        
        await ctx.send(embed=embed)

    @toggle_pictures.error
    async def toggle_pictures_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need 'Manage Messages' permission to toggle profile picture display.")